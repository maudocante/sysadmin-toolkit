#!/bin/bash
df -h
