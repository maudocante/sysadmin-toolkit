#!/bin/bash
free -h
